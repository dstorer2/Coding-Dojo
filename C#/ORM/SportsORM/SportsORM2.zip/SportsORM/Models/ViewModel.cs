using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace SportsORM.Models
{
    public class ViewModel
    {
        public List<object> List {get; set; }
    }
}

