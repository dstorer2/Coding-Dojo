namespace Phones
{
    interface IRingable
    {
        string Ring();
        string Unlock();
    }
}