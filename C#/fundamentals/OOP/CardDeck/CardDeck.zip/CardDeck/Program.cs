﻿namespace CardDeck
{
    class Program
    {
        public static void Main(string[] args)
        {
            Deck myDeck = new Deck();
        }
    }
}