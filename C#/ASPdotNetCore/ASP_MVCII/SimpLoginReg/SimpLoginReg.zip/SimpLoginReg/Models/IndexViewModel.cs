namespace SimpLoginReg
{
    public class IndexViewModel
    {
        public Register NewRegistration {get; set; }
        public Login NewLogin {get; set; }
    }
}