import React from "react";

const BadSearch = () => {
    return(
        <div>
            <h1>These are not the droids you are looking for...</h1>
            <img src="https://i.imgflip.com/ibo0i.jpg" alt="invalid search Kenobi" />
        </div>
    )
}
export default BadSearch;