import User from './components/User';
import './App.css';

function App() {
  return (
    <div className="App">
      <User />
    </div>
  );
}

export default App;
