import React, { useState } from 'react'

const User = (props) => {
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const[confirm, setConfirm] = useState("");

    const createUser = (e) => {
        e.preventDefault();
        const newUser = { firstName, lastName, email, password, confirm };
        console.log("Welcome", newUser);
        setFirstName("");
        setLastName("");
        setEmail("");
        setPassword("");
        setConfirm("");
    };

    return(
        <div>
            <form onSubmit={ createUser }>
                <div>
                    <label>First Name:</label>
                    <input type="text" onChange={ (event) => setFirstName(event.target.value) } value={ firstName }/>
                </div>
                <div>
                    <label>Last Name:</label>
                    <input type="text" onChange={ (event) => setLastName(event.target.value) }value={ lastName }/>
                </div>
                <div>
                    <label>Email:</label>
                    <input type="text" onChange={ (event) => setEmail(event.target.value) } value={ email }/>
                </div>
                <div>
                    <label>Password:</label>
                    <input type="text" onChange={ (event) => setPassword(event.target.value) } value={ password }/>
                </div>
                <div>
                    <label>Confirm password:</label>
                    <input type="text" onChange={ (event) => setConfirm(event.target.value)} value={ confirm }/>
                </div>
                <input type="submit" value=" Create User"/>
            </form>
            <p>First Name: { firstName }</p>
            <p>Last Name: { lastName }</p>
            <p>Email: { email }</p>
            <p>Password: { password }</p>
            <p>Confirm Password: { confirm }</p>
        </div>


    )
} 

export default User;