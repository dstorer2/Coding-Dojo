function nameChange(){
    userName.innerHTML = "Charlize Theron"
}

var hideElement = document.getElementById("#user")

function removeRequest(hideElement){
    user.remove();
}