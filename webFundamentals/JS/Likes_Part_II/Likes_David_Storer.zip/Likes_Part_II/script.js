var count1 = 0
var count2 = 0
var count3 = 0

var countElement1 = document.getElementById("likes1")
var countElement2 = document.getElementById("likes2")
var countElement3 = document.getElementById("likes3")

function addLike1() {
    count1++;
    likes1.innerHTML = count1 + " like(s)"
}

function addLike2() {
    count2++;
    likes2.innerHTML = count2 + " like(s)"
}

function addLike3() {
    count3++;
    likes3.innerHTML = count3 + " like(s)"
} 